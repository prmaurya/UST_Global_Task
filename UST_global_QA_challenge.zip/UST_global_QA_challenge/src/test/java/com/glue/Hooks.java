package com.glue;

import Utility.Constant;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Hooks {

    public static WebDriver driver;

    @Before()
    public void beforeScenario() {

        System.out.println("\n .....Before Starting the scenario...... \n");
        System.setProperty("webdriver.chrome.driver", Constant.driverpath);
        driver = new ChromeDriver();
    }

    @After()
    public void afterScenario() {

        System.out.println("\n....After Scenario is completed successfully.....\n");
        driver.quit();
    }

}
