package com.glue;

import Utility.Constant;
import org.junit.Assert;
import pageFactory.amazonTestSteps;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.java.en.And;
import org.openqa.selenium.WebDriver;

public class AmazonTest {

    WebDriver driver;
    amazonTestSteps stepObject;
    String expectedErrorMessage = "Enter your email or mobile phone number";


    @Given("^User navigates to Amazon Home page$")
    public void userNavigatesToAmazonHomePage() {
        driver = Hooks.driver;
        driver.get(Constant.amazonURL);
    }


    @When("^User hovers the mouse over sign in button and clicks on sign in below$")
    public void userHoversTheMouseOverSignInButtonAndClicksOnSignInBelow() {
        stepObject = new amazonTestSteps(driver);
        stepObject.hoverMouseOverSignIn();
        stepObject.scrollDownAndClickOnSignIn();
    }

    @And("^User submits without entering valid email$")
    public void userClicksOnSignInAndSubmitsWithoutEnteringValidEmail() {
        stepObject.clickOnContinue();
    }

    @Then("^Verify error message is shown and form is not submitted$")
    public void verifyErrorMessageIsShownAndFormIsNotSubmitted() {
         String actualErrorMessage =  stepObject.verifyErrorMessage();
         Assert.assertEquals(expectedErrorMessage, actualErrorMessage);
    }

}
