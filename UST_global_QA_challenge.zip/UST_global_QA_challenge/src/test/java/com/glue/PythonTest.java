package com.glue;

import Utility.Constant;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import pageFactory.pythonTestSteps;

public class PythonTest {

    WebDriver driver;
    pythonTestSteps stepObject;
    String expectedMessage = "Your success story submission has been recorded. It will be reviewed by the PSF staff and published.";

    @Given("^User navigates to Python home page$")
    public void userNavigatesToPythonHomePage() {
        driver = Hooks.driver;
        driver.get(Constant.pythonURL);
    }

    @When("^User clicks on submit success story in arts section$")
    public void userClicksOnSubmitSuccessStoryInArtsSection() {
        stepObject = new pythonTestSteps(driver);
        stepObject.clickOnSuccessStories();
        stepObject.clickOnSubmitYourStoryInArtsSection();
    }

    @And("^Populates all the necessary fields$")
    public void populatesAllTheNecessaryFields() {
        stepObject.populateAllFields();
    }

    @Then("^Verify user is able to submit the form and success message is displayed$")
    public void verifyUserIsAbleToSubmitTheFormAndSuccessMessageIsDisplayed() {
        stepObject.clickOnSubmit();
        String actualMessage = stepObject.getSuccessMessage();
        Assert.assertEquals(expectedMessage,actualMessage);
    }
}
