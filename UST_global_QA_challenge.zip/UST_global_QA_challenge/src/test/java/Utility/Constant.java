package Utility;

public class Constant {

    public static String amazonURL="https://www.amazon.com";
    public static String pythonURL = "http://www.python.org";
    public static String driverpath="./driver/chromedriver";


}
