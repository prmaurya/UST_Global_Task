package pageFactory;

import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.interactions.Actions;

public class amazonTestSteps {

    WebDriver driver;
    WebDriverWait wait;

    public amazonTestSteps(WebDriver driver){
        this.driver=driver;
        PageFactory.initElements(driver,this);
        wait = new WebDriverWait(driver,20);
    }


    @FindBy ( how = How.ID , using = "nav-link-accountList")
    WebElement signInDiv;

    public void hoverMouseOverSignIn() {

        wait.until(ExpectedConditions.visibilityOf(signInDiv));
        Actions action = new Actions(driver);
        action.moveToElement(signInDiv).build().perform();
    }

    public void scrollDownAndClickOnSignIn() {
        Actions action = new Actions(driver);
        action.moveToElement(signInDiv, 0, 50).click().build().perform();
    }


    @FindBy ( how = How.ID , using = "continue")
    WebElement continueBtn;

    public void clickOnContinue() {
        wait.until(ExpectedConditions.visibilityOf(continueBtn));
        continueBtn.click();
    }

    @FindBy (how = How.ID, using = "auth-email-missing-alert")
    WebElement errorDiv;

    public String verifyErrorMessage() {
        try {
            wait.until(ExpectedConditions.visibilityOf(errorDiv));
            return errorDiv.getText().trim();
        } catch (ElementNotVisibleException e)
        {
            return "Error message not found";
        }

    }
}
