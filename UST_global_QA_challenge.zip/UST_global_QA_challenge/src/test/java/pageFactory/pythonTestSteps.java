package pageFactory;

import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.Select;
import java.util.Random;

public class pythonTestSteps {

    WebDriver driver;
    WebDriverWait wait;

    public pythonTestSteps(WebDriver driver){
        this.driver=driver;
        PageFactory.initElements(driver,this);
        wait = new WebDriverWait(driver,20);
    }

    @FindBy ( how = How.ID , using = "success-stories")
    WebElement successStoriesBtn;

    public void clickOnSuccessStories() {

        wait.until(ExpectedConditions.visibilityOf(successStoriesBtn));
        Actions action = new Actions(driver);
        action.moveToElement(successStoriesBtn).build().perform();

    }

    @FindBy ( how = How.XPATH , using ="//a[@href='/success-stories/category/arts/']")
    WebElement artsBtn;

    @FindBy ( how = How.XPATH, using ="//a[@href='/success-stories/create/']")
    WebElement createBtn;

    public void clickOnSubmitYourStoryInArtsSection() {

       wait.until(ExpectedConditions.visibilityOf(artsBtn));
       artsBtn.click();

       wait.until(ExpectedConditions.visibilityOf(createBtn));
       createBtn.click();
    }

    @FindBy ( how = How.ID , using = "id_name")
    WebElement nameInput;

    @FindBy ( how = How.ID , using = "id_company_name")
    WebElement companyNameInput;

    @FindBy ( how = How.ID , using = "id_company_url")
    WebElement companyURLInput;

    @FindBy ( how = How.ID , using = "id_category")
    WebElement categorySelect;

    @FindBy ( how = How.ID, using = "id_author")
    WebElement authorInput;

    @FindBy ( how = How.ID, using = "id_author_email")
    WebElement authorEmailInput;

    @FindBy ( how = How.ID, using = "id_pull_quote")
    WebElement quoteInput;

    @FindBy ( how = How.ID , using = "id_content")
    WebElement contentInput;

    public void populateAllFields() {

        wait.until(ExpectedConditions.visibilityOf(nameInput));
        nameInput.sendKeys(randomString());
        companyNameInput.sendKeys(randomString());
        companyURLInput.sendKeys("Https://"+randomString()+".com");

        Select select = new Select (categorySelect);
        select.selectByVisibleText("Arts");

        authorInput.sendKeys(randomString());
        authorEmailInput.sendKeys(randomString()+"@gmail.com");
        quoteInput.sendKeys(randomString());
        contentInput.sendKeys(randomString());
    }

    @FindBy ( how = How.NAME, using = "Submit")
    WebElement submitBtn;

    public void clickOnSubmit() {
        wait.until(ExpectedConditions.visibilityOf(submitBtn));
        submitBtn.click();
    }

    public static String randomString() {
        String candidateChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvxyz";
        int targetStringLength = 10;
        StringBuilder sb = new StringBuilder(targetStringLength);
        Random random = new Random();
        for (int i = 0; i < targetStringLength; i++) {
            sb.append(candidateChars.charAt(random.nextInt(candidateChars.length())));
        }
        return sb.toString();
    }

    @FindBy (how = How.CLASS_NAME, using = "level-success")
    WebElement successMessage;

    public String getSuccessMessage() {

        try {
            wait.until(ExpectedConditions.visibilityOf(successMessage));
            return successMessage.getText().trim();
        }
        catch (ElementNotVisibleException e)
        {
            return "Success Message not shown";
        }

    }
}
